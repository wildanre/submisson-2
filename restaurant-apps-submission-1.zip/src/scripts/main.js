document.addEventListener('DOMContentLoaded', async () => {
    try {
        // Mengambil data dari file DATA.js
        const response = await import('../public/data/data.js'); // Menggunakan import untuk mendapatkan data
        const data = response.default; // Mengambil default export dari DATA.js
        console.log(data);  // Tambahkan log ini untuk memastikan data diambil

        const postsContainer = document.querySelector('.posts');
        console.log(postsContainer);  // Pastikan postsContainer ditemukan

        // Mengiterasi setiap restoran dan menambahkan ke container
        data.restaurants.forEach((restaurant) => {
            const contentItem = document.createElement('content-item');
            contentItem.content = restaurant; // Mengatur konten dari custom element
            postsContainer.appendChild(contentItem); // Menambahkan elemen ke container
        });
    } catch (error) {
        console.error('Error fetching or displaying data:', error);
    }
});
