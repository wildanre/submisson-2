import './components/script.js';
import './utils/utils.js';
// import '../styles/main.css';
import './main.js';
import '../styles/main.scss';
